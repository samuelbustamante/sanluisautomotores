# -*- coding:utf-8 -*-

from django.conf.urls.defaults import patterns, include, url
from django.views.generic.simple import direct_to_template
from views import home

urlpatterns = patterns('',
    url(r'^$', home,
        {'template_name': 'home/home.html'}, name='home'
    ),
    url(r'^terminos_y_condiciones/$', direct_to_template,
        {'template_name': 'home/terms.html'}, name='terms'
    ),
    url(r'^politicas_de_privacidad/$', direct_to_template,
        {'template_name': 'home/policies.html'}, name='policies'
    ),
    url(r'^sobre_nosotros/$', direct_to_template,
        {'template_name': 'home/about_us.html'}, name='about_us' 
    ),
)

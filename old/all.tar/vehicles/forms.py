# -*- coding: utf-8 -*-

from django import forms
from models import Vehicle

class VehicleForm(models.ModelForm):
    class Meta:
        model = Vehicle
        exclude = ('user',)

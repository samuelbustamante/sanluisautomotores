# -*- coding: utf-8 -*-

VEHICLES = (
    ('1', u'Autos'),
    ('2', u'Motos'),
)

LOCATIONS = (
    ('1', u'San Luis'), ('2', u'Villa Mercedes'),
    ('3', u'Merlo'), ('4', u'La Punta'),
    ('5', u'Juana Koslay'), ('6', u'Justo Daract'),
    ('7', u'La Toma'), ('8', u'Quines'),
    ('9', u'Tilisarao'), ('10', u'Concarán'),
    ('11', u'Santa Rosa del Conlara'), ('12', u'Naschel'),
    ('13', u'San Francisco del Monte de Oro'), ('14', u'Buena Esperanza'),
    ('15', u'Unión'), ('16', u'Candelaria'),
    ('17', u'Potrero de los Funes'), ('18', u'El Volcán')
)

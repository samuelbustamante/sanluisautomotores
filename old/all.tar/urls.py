from django.conf.urls.defaults import patterns, url, include
from django.contrib import admin

admin.autodiscover()

urlpatterns = patterns('',
    url(r'^', include('myproject.home.urls')),
    #url(r'^automotores', include('myproject.vehicles.urls')),
    url(r'^registracion', include('myproject.registration.urls')),
    url(r'^admin/', include(admin.site.urls)),
)
